import Lean.Data.Json

open Lean

namespace ProofScript.WasmSpike

structure Request where
  message : String
  count : Nat
deriving FromJson, ToJson

structure Response where
  text : String
  length : Nat
deriving FromJson, ToJson

structure ErrorBody where
  code : String
  message : String
deriving ToJson

private def success (value : Json) : Json :=
  Json.mkObj [("ok", true), ("value", value)]

private def failure (code message : String) : Json :=
  Json.mkObj [("ok", false), ("error", toJson ({ code, message } : ErrorBody))]

def compute (request : Request) : Except String Response := do
  if request.count > 1000 then
    throw "count must not exceed 1000"
  let text := String.join (List.replicate request.count request.message)
  return { text, length := text.utf8ByteSize }

def invokeJson [FromJson α] [ToJson β]
    (f : α → Except String β) (input : String) : String :=
  let result := do
    let json ← Json.parse input |>.mapError fun error => failure "invalid-json" error
    let request ← fromJson? json |>.mapError fun error => failure "invalid-input" error
    let response ← f request |>.mapError fun error => failure "computation-error" error
    return success (toJson response)
  Json.compress <| match result with
    | .ok response => response
    | .error error => error

/-- JSON ABI entry point used to validate typed decoding and structured errors. -/
@[export proof_script_spike]
def invoke (input : String) : String :=
  invokeJson compute input

end ProofScript.WasmSpike
