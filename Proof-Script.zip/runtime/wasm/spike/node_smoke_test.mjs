import assert from "node:assert/strict";
import { writeFile } from "node:fs/promises";

const started = process.hrtime.bigint();
const module = await import("./build/proof_script_spike.mjs");
const factory = module.default;
const instance = await factory();
instance._proof_script_init();
const initialized = process.hrtime.bigint();

const input = new TextEncoder().encode("hello");
const inputPtr = instance._proof_script_alloc(input.byteLength);
const output = instance._proof_script_alloc(128);
instance.HEAPU8.set(input, inputPtr);
const written = instance._proof_script_invoke(inputPtr, input.byteLength, output, 128);
const result = new TextDecoder().decode(instance.HEAPU8.slice(output, output + written));
assert.equal(result, "proof-script:hello");

const durations = [];
for (let i = 0; i < 1000; i += 1) {
  const before = process.hrtime.bigint();
  const n = instance._proof_script_invoke(inputPtr, input.byteLength, output, 128);
  durations.push(Number(process.hrtime.bigint() - before) / 1e6);
  assert.equal(n, written);
}

instance._proof_script_free(inputPtr);
instance._proof_script_free(output);
durations.sort((a, b) => a - b);
const report = {
  calls: 1001,
  result,
  initializationMs: Number(initialized - started) / 1e6,
  callsTotalMs: durations.reduce((sum, value) => sum + value, 0),
  callMeanMs: durations.reduce((sum, value) => sum + value, 0) / durations.length,
  callP95Ms: durations[Math.floor(durations.length * 0.95)],
};
await writeFile("runtime/wasm/spike/build/benchmark-report.json", `${JSON.stringify(report, null, 2)}\n`);
console.log(JSON.stringify(report));
