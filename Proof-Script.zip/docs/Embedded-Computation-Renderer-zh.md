# 嵌入式计算渲染协议

`#computation` 用于把 Lean 声明与网页交互组件连接起来。页面 JSON 负责携带可追溯的 Lean
来源、稳定的组件外壳和 renderer 专用 manifest；`function.implementation` 指向同一表达式表中的
函数实现体。该实现不把 Lean 编译器内部 IR 误当作稳定的
JavaScript 或 WebAssembly ABI。

## 数据契约

组件 `schemaVersion` 独立于页面 schema，当前为 `1.0.0`。renderer 必须：

1. 拒绝不支持的组件 major version。
2. 按完整 `renderer` ID 分派，例如 `proof-script/e8-root-explorer-v1`。
3. 校验该 renderer 自己定义的 `payload` schema。
4. 用 `function.declaration` 和 `function.type` 展示来源，用 `expression`、`implementation` 与 `expressions` 做审计、索引或静态分析。
5. 不直接执行页面提供的任意脚本，不把 `payload` 字符串拼接进 DOM。
6. renderer 不可用、JavaScript 被禁用或 manifest 校验失败时显示 `payload.fallback`。

## 执行后端

建议 renderer 为每个计算组件显式选择以下后端之一：

| 后端 | 用途 | 页面产物 | 信任边界 |
| --- | --- | --- | --- |
| `table` | 有限输入、教学演示、离线文档 | 编译期生成或核验的输入输出表 | renderer 只查表 |
| `wasm` | 纯函数、大量客户端计算 | 带 hash 的 Wasm resource、导出名、编解码 schema | 在 Worker 中限制内存和时间 |
| `rpc` | 依赖大型 Lean 环境或服务端证明检查 | endpoint capability、请求/响应 schema | 服务端重新校验所有输入 |
| `declarative` | 投影、公式、状态机等专用可视化 | renderer 专用参数 | 不执行通用代码 |

首版 Proof-Script 实现导出 Lean 表达式 DAG 作为中间产物，并允许 `table` 或 `declarative`
renderer 立即工作。未来增加 Wasm 时，应把二进制写入 `.Proof-Script/resources/wasm/`，以
`$resource` 携带 path、hash、mediaType 和 encoding；无需改变 `computation` 外壳。

## 浏览器实现流程

1. 页面加载器按照页面顺序读取 component envelope。
2. 遇到 `computation` 时先渲染标题和 fallback，避免 hydration 前空白。
3. renderer registry 按完整 ID 动态加载受信任模块，未知 ID 保留 fallback。
4. 用 JSON Schema 校验 `payload`，并检查函数类型是否符合 renderer 预期。
5. 将昂贵计算放入 Web Worker；设置输入大小、运行时间、内存和输出大小上限。
6. 以结构化状态更新视图，不使用 `eval`、`new Function` 或未经清理的 `innerHTML`。
7. 在界面同时显示计算结果、Lean 声明链接和“计算示例不等于一般性证明”的边界说明。

建议的 TypeScript 分派接口：

```ts
type ComputationRenderer = {
  payloadSchema: object;
  mount(host: HTMLElement, value: ComputationValue, signal: AbortSignal): Promise<void>;
};

const computationRenderers = new Map<string, () => Promise<ComputationRenderer>>([
  ["proof-script/e8-root-explorer-v1", loadE8RootExplorer],
]);
```

## E8 Demo renderer

`proof-script/e8-root-explorer-v1` 应实现四个联动视图：

1. 根族选择器调用表后端，展示整数族 `112`、半整数族 `128` 和总数 `240`。
2. 坐标检查器按 manifest 中的精确规则生成根，使用有理数而非浮点数计算范数平方 `2`。
3. 投影视图允许切换 Coxeter 平面和坐标投影，按根族着色，并强调投影不是八维格子本身。
4. 密度视图允许把半径拖到 `sqrt(2)/2` 两侧，联动展示 separation 证书有效性及
   `vol(B^8(sqrt(2)/2)) / covolume(E8) = pi^4/384`。

有限枚举说明 240 个最小根的结构；非零格点不存在更短向量仍由 `E8_norm_lower_bound` 等 Lean
定理承担。renderer 应始终显示这一区别，并链接 manifest 的 `formalDeclarations`。
