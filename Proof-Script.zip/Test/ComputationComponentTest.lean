import ProofScript

def chooseOffset (large : Bool) : Nat :=
  if large then 128 else 112

#computation
  (title := "Finite computation", label := "finite-computation")
  "proof-script/test-table-v1"
  chooseOffset
  r#"{"inputs":[{"value":false,"output":112},{"value":true,"output":128}]}"#

#page_end
