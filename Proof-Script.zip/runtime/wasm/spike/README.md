# Lean Wasm Spike

This directory is the Phase 1 pipeline probe. It deliberately does not use the
page computation component and does not attempt to interpret Lean expression JSON.

## Pipeline

```text
Spike.lean --(Lean C backend)--> build/Spike.c
build/Spike.c + proof_script_shim.c --(Emscripten)--> proof_script_spike.mjs/.wasm
Node smoke test --> 1001 calls through the exported ABI
```

The Lean entry point is a pure `String -> String` function. The C shim exposes a
small fixed ABI and keeps Lean's `lean_object*` representation behind the boundary.
The eventual JSON ABI should replace the string prefix with validated JSON codecs,
but the runtime/linking path remains the same.

## Run

```sh
source "$HOME/Developer/emsdk/emsdk_env.sh"
./runtime/wasm/spike/build_lean_runtime.sh
PROOF_SCRIPT_LEAN_WASM_PREFIX="$HOME/Developer/lean4-wasm-4.32.0/build/proof-script-emscripten" \
  ./runtime/wasm/spike/build.sh
node runtime/wasm/spike/node_smoke_test.mjs
```

If libuv cannot be downloaded during the runtime build, an existing v1.48.0
checkout can be supplied without changing global Git proxy settings:

```sh
PROOF_SCRIPT_LIBUV_SOURCE=/path/to/libuv-v1.48.0 \
  ./runtime/wasm/spike/build_lean_runtime.sh
```

If a compatible runtime prefix already exists, only the last two commands are
needed:

```sh
./runtime/wasm/spike/build.sh
node runtime/wasm/spike/node_smoke_test.mjs
```

The build always produces `build/Spike.c` and `build/build-report.json`. If `emcc`
is unavailable it exits successfully after reporting `status: pending`; the Wasm
link and Node smoke test are then intentionally unavailable rather than silently
using a native library.

The expected pinned inputs are Lean 4.32.0 and the Lean commit reported by
`lean --githash`. The Emscripten link also requires a target-platform Lean
prefix, not the host macOS libraries:

```sh
PROOF_SCRIPT_LEAN_WASM_PREFIX=/path/to/emscripten/lean-prefix \
  ./runtime/wasm/spike/build.sh
```

That prefix must contain `lib/lean/libleanrt.a` and `lib/lean/libInit.a`
produced by the same Lean source commit. The build script intentionally refuses
to link the host's `libleanrt.a`. Once the toolchain is available, the project
should pin the Emscripten version in CI and include it in `build-report.json`.

Lean 4.32.0 contains two Emscripten fallback definitions whose C signatures do
not match their headers. `build_lean_runtime.sh` applies the narrow compatibility
patch in `lean-4.32.0-emscripten.patch`; it rejects an unrelated or mismatched
Lean checkout instead of applying the patch fuzzily.

The target platform is selected by `emcmake` (`CMAKE_SYSTEM_NAME=Emscripten`);
the CMake build type remains `Release`. The historical documentation's
`CMAKE_BUILD_TYPE=Emscripten` omits the current release optimization flags.

Lean's current Emscripten settings build the runtime with pthread support. A
browser deployment therefore needs cross-origin isolation for SharedArrayBuffer
(`Cross-Origin-Opener-Policy: same-origin` and
`Cross-Origin-Embedder-Policy: require-corp`). Removing that requirement by
building a single-thread runtime is a follow-up optimization, not part of this
pipeline feasibility spike.
