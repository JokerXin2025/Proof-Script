import ProofScript.Extension.Component.Core
import ProofScript.Script.ExprJSON

open Lean
open Lean.Elab.Command (CommandElabM liftIO liftTermElabM)
open ProofScript.Extension


namespace ProofScript.Extension


/-- Stable description of the Lean declaration backing an interactive computation. -/
structure ComputationFunction where
  declaration : String
  type : String
  expression : Json
  implementation : Json
  expressions : Json
deriving Inhabited, ToJson

/--
Page-level contract for an interactive computation.

`payload` is interpreted by the named renderer. Proof-Script additionally exports a
structured Lean expression as provenance and an intermediate artifact; it is not a
browser execution ABI. Renderers should select an execution backend by `renderer`.
-/
structure ComputationComponent where
  schemaVersion : String := "1.0.0"
  metadata : ComponentMetadata
  renderer : String
  function : ComputationFunction
  payload : Json
deriving Inhabited, ToJson

private def parseJsonAt (stx : Syntax) (source : String) : CommandElabM Json :=
  match Json.parse source with
  | .ok value => pure value
  | .error message => throwErrorAt stx s!"invalid #computation payload JSON: {message}"

private def resolveDeclaration (stx : Syntax) (name : Name) : CommandElabM Name := do
  let env ← getEnv
  let candidates := ((← getCurrNamespace) ++ name) :: (← getOpenDecls).filterMap fun
    | .simple ns _ => some (ns ++ name)
    | .explicit ns alias => if alias == name then some ns else none
  let candidates := candidates ++ [name]
  let some resolved := candidates.find? env.contains
    | throwErrorAt stx s!"unknown Lean declaration '{name}'"
  return resolved

private def addComputationComponent (metadataStx : Syntax)
                                    (rendererStx : TSyntax `str)
                                    (functionStx : TSyntax `ident)
                                    (payloadStx : TSyntax `str)
                                    : CommandElabM Unit := do
  let metadata ←  match parseComponentMetadata metadataStx with
                  | .ok metadata => pure metadata
                  | .error message => throwErrorAt metadataStx message
  let declaration ← resolveDeclaration functionStx.raw functionStx.getId
  let env ← getEnv
  let info := env.constants.find! declaration
  let implementation ← match info with
    | .defnInfo value => pure value.value
    | .opaqueInfo value => pure value.value
    | _ => throwErrorAt functionStx s!"#computation requires a definition with an implementation; '{declaration}' is not executable"
  liftIO ProofScript.resetExprJsonState
  let expression ← liftTermElabM do
    ProofScript.Expr2JSON (.const declaration [])
  let implementation ← liftTermElabM do
    ProofScript.Expr2JSON implementation
  let expressions ← liftIO ProofScript.getExprJsonTable
  let type ← liftTermElabM do
    return toString (← Meta.ppExpr info.type)
  let payload ← parseJsonAt payloadStx.raw payloadStx.getString
  let labels := match metadata.label with
    | some label => #[(("figure" : ReferenceKind), label)]
    | none => #[]
  let value : ComputationComponent := {
    metadata
    renderer := rendererStx.getString
    function := { declaration := declaration.toString, type, expression, implementation, expressions }
    payload
  }
  addPageComponent functionStx.raw "computation" (toJson value) labels

/--
Adds an interactive computation backed by a Lean declaration.

The final JSON string is a renderer-specific, versioned manifest. Keeping execution
behind a named renderer avoids treating Lean compiler internals as a stable web ABI.
-/
elab "#computation" metadata:componentMeta renderer:str function:ident payload:str : command =>
  addComputationComponent metadata.raw renderer function payload


end ProofScript.Extension
