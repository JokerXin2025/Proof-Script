import ProofScript

@[theorem_info (name := "Referenced declaration", label := "referenced-declaration")]
theorem declarationModeReference (P : Prop) (h : P) : P := h

#theorem recordedTheorem : True := script
  trivial

#lemma @[theorem_info (name := "Recorded lemma", label := "recorded-lemma")]
  recordedLemma : True := script
  trivial

#theorem tacticTheorem (P : Prop) (h : P) : P := by
  exact h

#lemma @[theorem_info (name := "Tactic lemma", label := "tactic-lemma")]
  tacticLemma (P : Prop) (h : P) : P := by
  exact declarationModeReference P h

#references
#page_end
